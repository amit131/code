module.exports = {
  standardversion:{
    src:[
      'standardversion/assets/js/app.src.js'
    ],
    dest:'standardversion/assets/js/app.min.js'
  },
  rtlversion:{
   src:[
      'rtlversion/assets/js/app.src.js'
    ],
    dest:'rtlversion/assets/js/app.min.js'
  }
};
